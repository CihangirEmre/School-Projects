package Vehicles;

public class Train extends Vehicle {
    public Train(int koltukSayisi) {
        super("elektrik", koltukSayisi);
    }

}
