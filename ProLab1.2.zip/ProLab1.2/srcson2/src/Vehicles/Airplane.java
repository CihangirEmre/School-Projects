package Vehicles;

public class Airplane extends Vehicle {
    public Airplane(int koltukSayisi) {
        super("gaz", koltukSayisi);
    }

}
