package Vehicles;

public class Bus extends Vehicle {
    public Bus(String yakitTuru, int koltukSayisi) {
        super(yakitTuru, koltukSayisi);
    }

}
