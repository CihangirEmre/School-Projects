package Vehicles;

public abstract class Vehicle {
    public String yakitTuru;
    public int koltukSayisi;

    public Vehicle(String yakitTuru, int koltukSayisi) {
        this.yakitTuru = yakitTuru;
        this.koltukSayisi = koltukSayisi;
    }

    static public int CalculateFuelCost(int kilometre, String yakitTuru, String firmaAd){
        int yakitFiyat = 0;

        if (firmaAd.equals("A")) {
            switch (yakitTuru) {
                case "benzin":
                    yakitFiyat = 10;
                    break;
            }
        } else if (firmaAd.equals("B")) {
            switch (yakitTuru) {
                case "motorin":
                    yakitFiyat = 5;
                    break;
            }
        } else if (firmaAd.equals("C")) {
            switch (yakitTuru) {
                case "motorin":
                    yakitFiyat = 6;
                    break;
                case "gaz":
                    yakitFiyat = 25;
                    break;
            }
        } else if (firmaAd.equals("D")) {
            switch (yakitTuru) {
                case "elektrik":
                    yakitFiyat = 3;
                    break;
            }
        } else if (firmaAd.equals("F")) {
            switch (yakitTuru) {
                case "gaz":
                    yakitFiyat = 20;
                    break;
            }
        } else {
            switch (yakitTuru) {
                case "benzin":
                    yakitFiyat = 10;
                    break;
                case "motorin":
                    yakitFiyat = 6;
                    break;
                case "elektrik":
                    yakitFiyat = 3;
                    break;
                case "gaz":
                    yakitFiyat = 20;
                    break;
            }
        }

        return kilometre * yakitFiyat;
    };
}
