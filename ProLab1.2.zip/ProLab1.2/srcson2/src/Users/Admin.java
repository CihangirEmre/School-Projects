package Users;

public class Admin extends User{
    public Admin(String kullaniciAdi, String sifre) { super(kullaniciAdi, sifre); }
}
