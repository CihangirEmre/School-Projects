package Others;

import Persons.Passenger;

public class Reservation {
    public String aracAd;
    public String firmaAd;
    public int koltukBilgisi;
    public Passenger yolcu;


    public Reservation(Passenger yolcu, String aracAd, String firmaAd, int koltukBilgisi) {
        this.yolcu = yolcu;
        this.aracAd = aracAd;
        this.firmaAd = firmaAd;
        this.koltukBilgisi = koltukBilgisi;
    }
}
