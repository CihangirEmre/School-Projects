package Others;

import Vehicles.Vehicle;

import java.util.ArrayList;
import java.util.List;

public class Content {
    public String tarih;
    public List<CompanyEarnings> list = new ArrayList<>();

    static public List<Content> icerikList = new ArrayList<>();

    public Content(String tarih, List<CompanyEarnings> list) {
        this.tarih = tarih;
        this.list = list;
    }
    static public int hesapla(Trip trip) {
        int ucret = 0;

        if (trip.aracAd.contains("otobus")) {
            ucret = 300;
        }
        else if (trip.aracAd.contains("tren")) {
            boolean check = true;
            String s = trip.guzergah.get(4);

            if (s.equals("Ankara")) {
                check = true;
            }

            if (check) {
                ucret = 250;
            } else {
                ucret = 300;
            }
        }
        else if (trip.aracAd.contains("ucak")) {
            boolean check = true;
            String s = trip.guzergah.get(1);

            if (s.equals("Konya")) {
                check = true;
            }

            if (check) {
                ucret = 1200;
            } else {
                ucret = 1000;
            }
        }

        return ucret * 2;
    }

    static public int giderHesapla(Trip trip) {
        int ucret = 0;

        if (trip.aracAd.contains("otobus")) {
            boolean check = false;
            String s = trip.guzergah.get(2);

            if (s.equals("Ankara")) {
                check = true;
            }

            if (check) {
                ucret = Vehicle.CalculateFuelCost(1000,trip.aracTuru.yakitTuru, trip.firmaAd);
            } else {
                ucret = Vehicle.CalculateFuelCost(1200,trip.aracTuru.yakitTuru, trip.firmaAd);
            }
        }
        else if (trip.aracAd.contains("tren")) {
            boolean check = false;
            String s = trip.guzergah.get(4);

            if (s.equals("Ankara")) {
                check = true;
            }

            if (check) {
                ucret = Vehicle.CalculateFuelCost(750,trip.aracTuru.yakitTuru, trip.firmaAd);
            } else {
                ucret = Vehicle.CalculateFuelCost(900,trip.aracTuru.yakitTuru, trip.firmaAd);
            }
        }
        else if (trip.aracAd.contains("ucak")) {
            boolean check = false;
            String s = trip.guzergah.get(1);

            if (s.equals("Konya")) {
                check = true;
            }

            if (check) {
                ucret = Vehicle.CalculateFuelCost(600,trip.aracTuru.yakitTuru, trip.firmaAd);
            } else {
                ucret = Vehicle.CalculateFuelCost(500,trip.aracTuru.yakitTuru, trip.firmaAd);
            }
        }


        return ucret;
    }

    static public int giderBul(Customer musteri) {
        int kullanilcak = 0;

        if (musteri.rezervasyon.aracAd.contains("otobus")) {
            for (Trip trip : Trip.otobusListesi) {
                if (trip.aracAd.equals(musteri.rezervasyon.aracAd) &&
                        trip.firmaAd.equals(musteri.rezervasyon.firmaAd) &&
                        trip.zaman.equals(musteri.rota.seferTarih)) {
                    kullanilcak = giderHesapla(trip);
                }
            }
        } else if (musteri.rezervasyon.aracAd.contains("tren")) {
            for (Trip trip : Trip.trenListesi) {
                if (trip.aracAd.equals(musteri.rezervasyon.aracAd) &&
                        trip.firmaAd.equals(musteri.rezervasyon.firmaAd) &&
                        trip.zaman.equals(musteri.rota.seferTarih)) {
                    kullanilcak = giderHesapla(trip);
                }
            }
        } else if (musteri.rezervasyon.aracAd.contains("ucak")) {
            for (Trip trip : Trip.ucakListesi) {
                if (trip.aracAd.equals(musteri.rezervasyon.aracAd) &&
                        trip.firmaAd.equals(musteri.rezervasyon.firmaAd) &&
                        trip.zaman.equals(musteri.rota.seferTarih)) {
                    kullanilcak = giderHesapla(trip);
                }
            }
        }

        return kullanilcak;
    }

    static public int gelirBul(Customer musteri) {
        int fiyat = 0;

        if (musteri.rezervasyon.aracAd.contains("otobus")) {
            int kalkisIndex = indexBulOtobus(musteri.rota.kalkisNoktasi);
            int varisIndex = indexBulOtobus(musteri.rota.varisNoktasi);

            int[] kullanilcakDizi = Trip.karayoluKalkisListesiFiyat.get(kalkisIndex);
            fiyat = kullanilcakDizi[varisIndex];

        } else if (musteri.rezervasyon.aracAd.contains("tren")) {
            int kalkisIndex = indexBulTren(musteri.rota.kalkisNoktasi);
            int varisIndex = indexBulTren(musteri.rota.varisNoktasi);

            int[] kullanilcakDizi = Trip.demiryoluKalkisListesiFiyat.get(kalkisIndex);
            fiyat = kullanilcakDizi[varisIndex];

        } else if (musteri.rezervasyon.aracAd.contains("ucak")) {
            int kalkisIndex = indexBulUcak(musteri.rota.kalkisNoktasi);
            int varisIndex = indexBulUcak(musteri.rota.varisNoktasi);

            int[] kullanilcakDizi = Trip.havayoluKalkisListesiFiyat.get(kalkisIndex);
            fiyat = kullanilcakDizi[varisIndex];
        }

        return fiyat;
    }

    static public int indexBulOtobus(String x) {
        int varisIndex = -1;

        switch (x) {
            case "Istanbul":
                varisIndex = 0;
                break;
            case "Kocaeli":
                varisIndex = 1;
                break;
            case "Ankara":
                varisIndex = 2;
                break;
            case "Eskisehir":
                varisIndex = 3;
                break;
            case "Konya":
                varisIndex = 4;
                break;
        }

        return varisIndex;
    }

    static public int indexBulTren(String x) {
        int varisIndex = -1;

        switch (x) {
            case "Istanbul":
                varisIndex = 0;
                break;
            case "Kocaeli":
                varisIndex = 1;
                break;
            case "Bilecik":
                varisIndex = 2;
                break;
            case "Ankara":
                varisIndex = 3;
                break;
            case "Eskisehir":
                varisIndex = 4;
                break;
            case "Konya":
                varisIndex = 5;
                break;
        }

        return varisIndex;
    }

    static public int indexBulUcak(String x) {
        int varisIndex = -1;

        switch (x) {
            case "Istanbul":
                varisIndex = 0;
                break;
            case "Ankara":
                varisIndex = 1;
                break;
            case "Konya":
                varisIndex = 2;
        }

        return varisIndex;
    }
}
