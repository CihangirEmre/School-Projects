package Others;

public interface IProfitable {
    int karZararDurumu(int gelir, int gider);
}
