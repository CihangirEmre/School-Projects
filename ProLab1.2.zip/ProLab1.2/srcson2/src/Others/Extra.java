package Others;

import java.util.ArrayList;
import java.util.List;

public class Extra {
    public String tarih;
    public String firmaAd;
    public int fiyat;
    static public List<Extra> extraList = new ArrayList<>();

    public Extra(String tarih, String firmaAd, int fiyat) {
        this.tarih = tarih;
        this.firmaAd = firmaAd;
        this.fiyat = fiyat;
    }

    static public void yeniEkle(Customer musteri) {
        int gelir = Content.gelirBul(musteri);

        extraList.add(new Extra(musteri.rota.seferTarih, musteri.rezervasyon.firmaAd, gelir));
    }
}
