package Others;

public interface ILoginable {
    boolean login(String gelenKullaniciAdi, String gelenSifre);
}
