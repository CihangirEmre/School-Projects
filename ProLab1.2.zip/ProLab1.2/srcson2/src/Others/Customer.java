package Others;

import Persons.Passenger;

import java.util.ArrayList;
import java.util.List;

public class Customer {
    public Reservation rezervasyon;
    public Route rota;

    static public List<Customer> musteriList = new ArrayList<>();

    public Customer(Reservation rezervasyon, Route rota) {
        this.rezervasyon = rezervasyon;
        this.rota = rota;

        musteriEkle(this);
    }

    static public void musteriEkle(Customer musteri) {
        Customer.musteriList.add(musteri);
    }
}
