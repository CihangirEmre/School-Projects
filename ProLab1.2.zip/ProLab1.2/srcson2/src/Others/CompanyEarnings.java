package Others;


import Persons.Personel;

import java.util.ArrayList;
import java.util.List;

//ilk önce her firma için en baştaki koltuk sayısı kadar gelir gider hesapla,
// sonra rezerve edilen her koltugun sadece bilet fiyatını mevcut gelir gidere ekle.
public class CompanyEarnings {
    public String firmaAd;
    public int gelir;
    public int gider;

    public CompanyEarnings(String firmaAd, int gelir, int gider) {
        this.firmaAd = firmaAd;
        this.gelir = gelir;
        this.gider = gider;
    }
    static public void hesapla() {
        List<Trip> butunAraclar = new ArrayList<>();
        butunAraclar.addAll(Trip.otobusListesi);
        butunAraclar.addAll(Trip.trenListesi);
        butunAraclar.addAll(Trip.ucakListesi);

        String[] tarihler = {"04.12.2023", "05.12.2023", "06.12.2023", "07.12.2023",
                "08.12.2023", "09.12.2023", "10.12.2023"};

        for (String tarih : tarihler) {
            boolean check = false;
            List<CompanyEarnings> kazancListesi = new ArrayList<>();

            for (Trip trip : butunAraclar) {
                if (trip.zaman.equals(tarih)) {
                    int kisiSayisi = 0;

                    for (Transport transport : Transport.koltukDurumutList) {
                        if (transport.firmaAd.equals(trip.firmaAd) && transport.aracAd.equals(trip.aracAd)) {
                            kisiSayisi = transport.doluKoltuksayisi;
                        }
                    }

                    check = true;
                    Personel personel = Personel.calisanUcret(trip.firmaAd, trip.aracAd);
                    int ucret = Content.hesapla(trip) * kisiSayisi;
                    int gider = Content.giderHesapla(trip) + (personel.personelUcret + personel.kullananUcret);
                    kazancListesi.add(new CompanyEarnings(trip.firmaAd, ucret, gider));
                }
            }

            if (check) {
                Content.icerikList.add(new Content(tarih, kazancListesi));
            }
        }

        if (!Extra.extraList.isEmpty()) {
            for (Extra extra : Extra.extraList) {
                boolean check1 = false;

                for (Content a : Content.icerikList) {

                    if (a.tarih.equals(extra.tarih)) {

                        for (CompanyEarnings b : a.list) {

                            if (b.firmaAd.equals(extra.firmaAd)) {
                                b.gelir += extra.fiyat;
                                check1 = true;

                                break;
                            }
                        }
                    }
                    if (check1) {
                        break;
                    }
                }
            }
        }
    }
}
