package Others;

public class selectedInputs {
    public static String kalkisNoktasi;
    public static String varisNoktasi;
    public static String tarih;
    public static int kisiSayisi;
}
