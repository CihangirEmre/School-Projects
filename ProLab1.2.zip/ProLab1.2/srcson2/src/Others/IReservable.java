package Others;

public interface IReservable {
    int koltukSec(int KoltukNo);
}
