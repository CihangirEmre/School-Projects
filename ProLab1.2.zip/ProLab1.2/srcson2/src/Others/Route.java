package Others;


public class Route {
    public String kalkisNoktasi;
    public String varisNoktasi;
    public int mesafe;
    public String seferTarih;


    public Route (String kalkisNoktasi, String varisNoktasi, String seferTarih, String aracAd, String firmaAd) {
        this.kalkisNoktasi = kalkisNoktasi;
        this.varisNoktasi = varisNoktasi;
        this.mesafe = mesafeBul(aracAd, firmaAd);
        this.seferTarih = seferTarih;
    }

    private int mesafeBul(String aracAd, String firmaAd) {
        int mesafe = 0;

        if (aracAd.contains("otobus")) {
            int kalkisIndex = indexBulOtobus(this.kalkisNoktasi);
            int varisIndex = indexBulOtobus(this.varisNoktasi);

            int[] kullanilcakDizi = Trip.karayoluKalkisListesi.get(kalkisIndex);
            mesafe += kullanilcakDizi[varisIndex];

        } else if (aracAd.contains("tren")) {
            int kalkisIndex = indexBulTren(this.kalkisNoktasi);
            int varisIndex = indexBulTren(this.varisNoktasi);

            int[] kullanilcakDizi = Trip.demiryoluKalkisListesi.get(kalkisIndex);
            mesafe += kullanilcakDizi[varisIndex];

        } else if (aracAd.contains("ucak")) {
            int kalkisIndex = indexBulUcak(this.kalkisNoktasi);
            int varisIndex = indexBulUcak(this.varisNoktasi);

            int[] kullanilcakDizi = Trip.havayoluKalkisListesi.get(kalkisIndex);
            mesafe += kullanilcakDizi[varisIndex];
        }

        for (Transport transport : Transport.koltukDurumutList) {
            if (transport.firmaAd.equals(firmaAd) && transport.aracAd.equals(aracAd)) {
                transport.toplamKoltuksayisi--;
            }
        }

        return mesafe;
    }

    private int indexBulOtobus(String x) {
        int varisIndex = -1;

        switch (x) {
            case "Istanbul":
                varisIndex = 0;
                break;
            case "Kocaeli":
                varisIndex = 1;
                break;
            case "Ankara":
                varisIndex = 2;
                break;
            case "Eskisehir":
                varisIndex = 3;
                break;
            case "Konya":
                varisIndex = 4;
                break;
        }

        return varisIndex;
    }

    private int indexBulTren(String x) {
        int varisIndex = -1;

        switch (x) {
            case "Istanbul":
                varisIndex = 0;
                break;
            case "Kocaeli":
                varisIndex = 1;
                break;
            case "Bilecik":
                varisIndex = 2;
                break;
            case "Ankara":
                varisIndex = 3;
                break;
            case "Eskisehir":
                varisIndex = 4;
                break;
            case "Konya":
                varisIndex = 5;
                break;
        }

        return varisIndex;
    }

    private int indexBulUcak(String x) {
        int varisIndex = -1;

        switch (x) {
            case "Istanbul":
                varisIndex = 0;
                break;
            case "Ankara":
                varisIndex = 1;
                break;
            case "Konya":
                varisIndex = 2;
        }

        return varisIndex;
    }
}
