import Others.*;
import Persons.Passenger;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;


import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class SeferGoruntulemePanel extends JFrame{
    private JList list1;
    private JPanel seferPanel;
    private JList list2;
    private JButton rezerveEtButton;
    private JButton biletleriGoruntuleButton;
    private JLabel bosKoltuk;

    DefaultListModel firmaAdList = new DefaultListModel();
    DefaultListModel aracAdList = new DefaultListModel();

    DefaultListModel seferList = new DefaultListModel();
    DefaultListModel koltukList = new DefaultListModel();

    int yolcuSayiCheck = selectedInputs.kisiSayisi;

    List<int[]> koltukNo = new ArrayList<>();

    public SeferGoruntulemePanel() {

        add(seferPanel);
        setTitle("Seferler");
        setSize(600, 550);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Customer.musteriList.clear();

        for (Trip trip : Trip.otobusListesi) {
            if (trip.zaman.charAt(1) == selectedInputs.tarih.charAt(1)) {
                boolean check1 = false;
                boolean check2 = false;
                boolean check3 = false;


                for(String sehir : trip.guzergah) {
                    if (sehir.equals(selectedInputs.kalkisNoktasi)) {
                        check1 = true;
                    } else if (sehir.equals(selectedInputs.varisNoktasi)) {
                        check2 = true;
                    }
                }

                int bos = 0;
                if (check1 && check2) {
                    for (Transport transport : Transport.koltukDurumutList) {
                        if (transport.aracAd.equals(trip.aracAd) && transport.firmaAd.equals(trip.firmaAd)) {
                            if (transport.toplamKoltuksayisi - transport.doluKoltuksayisi >= selectedInputs.kisiSayisi) {
                                check3 = true;
                                bos = transport.toplamKoltuksayisi - transport.doluKoltuksayisi;

                                List<Integer> gecici = new ArrayList<>();
                                int[] koltuklar = new int[bos];
                                Random random = new Random();
                                for (int i = 0; i < bos; i++) {
                                    while (true) {
                                        int sayi = random.nextInt(transport.toplamKoltuksayisi) + 1;

                                        if (!gecici.contains(sayi)) {
                                            koltuklar[i] = sayi;
                                            gecici.add(sayi);
                                            break;
                                        }
                                    }
                                }
                                koltukNo.add(koltuklar);
                            }
                        }
                    }
                }

                if (check1 && check2 && check3) {
                    seferList.addElement(trip.aracAd + "   Firma: " + trip.firmaAd);
                    aracAdList.addElement(trip.aracAd);
                    firmaAdList.addElement(trip.firmaAd);
                }
            }
        }

        for (Trip trip : Trip.trenListesi) {
            if (trip.zaman.charAt(1) == selectedInputs.tarih.charAt(1)) {
                boolean check1 = false;
                boolean check2 = false;
                boolean check3 = false;

                for(String sehir : trip.guzergah) {
                    if (sehir.equals(selectedInputs.kalkisNoktasi)) {
                        check1 = true;
                    } else if (sehir.equals(selectedInputs.varisNoktasi)) {
                        check2 = true;
                    }
                }

                int bos = 0;
                if (check1 && check2) {
                    for (Transport transport : Transport.koltukDurumutList) {
                        if (transport.aracAd.equals(trip.aracAd) && transport.firmaAd.equals(trip.firmaAd)) {
                            if (transport.toplamKoltuksayisi - transport.doluKoltuksayisi >= selectedInputs.kisiSayisi) {
                                check3 = true;
                                bos = transport.toplamKoltuksayisi - transport.doluKoltuksayisi;

                                List<Integer> gecici = new ArrayList<>();
                                int[] koltuklar = new int[bos];
                                Random random = new Random();
                                for (int i = 0; i < bos; i++) {
                                    while (true) {
                                        int sayi = random.nextInt(transport.toplamKoltuksayisi) + 1;

                                        if (!gecici.contains(sayi)) {
                                            koltuklar[i] = sayi;
                                            gecici.add(sayi);
                                            break;
                                        }
                                    }
                                }
                                koltukNo.add(koltuklar);
                            }
                        }
                    }
                }

                if (check1 && check2 && check3) {
                    seferList.addElement(trip.aracAd + "   Firma: " + trip.firmaAd);
                    aracAdList.addElement(trip.aracAd);
                    firmaAdList.addElement(trip.firmaAd);
                }
            }
        }
        for (Trip trip : Trip.ucakListesi) {
            if (trip.zaman.charAt(1) == selectedInputs.tarih.charAt(1)) {
                boolean check1 = false;
                boolean check2 = false;
                boolean check3 = false;

                for (String sehir : trip.guzergah) {
                    if (sehir.equals(selectedInputs.kalkisNoktasi)) {
                        check1 = true;
                    } else if (sehir.equals(selectedInputs.varisNoktasi)) {
                        check2 = true;
                    }
                }

                int bos = 0;
                if (check1 && check2) {
                    for (Transport transport : Transport.koltukDurumutList) {
                        if (transport.aracAd.equals(trip.aracAd) && transport.firmaAd.equals(trip.firmaAd)) {
                            if (transport.toplamKoltuksayisi - transport.doluKoltuksayisi >= selectedInputs.kisiSayisi) {
                                check3 = true;
                                bos = transport.toplamKoltuksayisi - transport.doluKoltuksayisi;

                                List<Integer> gecici = new ArrayList<>();
                                int[] koltuklar = new int[bos];
                                Random random = new Random();
                                for (int i = 0; i < bos; i++) {
                                    while (true) {
                                        int sayi = random.nextInt(transport.toplamKoltuksayisi) + 1;

                                        if (!gecici.contains(sayi)) {
                                            koltuklar[i] = sayi;
                                            gecici.add(sayi);
                                            break;
                                        }
                                    }
                                }
                                koltukNo.add(koltuklar);
                            }
                        }
                    }
                }

                if (check1 && check2 && check3) {
                    seferList.addElement(trip.aracAd + "   Firma: " + trip.firmaAd);
                    aracAdList.addElement(trip.aracAd);
                    firmaAdList.addElement(trip.firmaAd);
                }
            }
        }
        list1.setModel(seferList);

        list1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 1) {
                    int selectedIndex = list1.getSelectedIndex();
                    list1.setSelectedIndex(selectedIndex);

                    int[] koltuk = koltukNo.get(selectedIndex);
                    koltukList.clear();
                    for (int k : koltuk) {
                        koltukList.addElement(k);
                    }
                    list2.setModel(koltukList);
                }

                bosKoltuk.setText("Boş koltuk: " + koltukList.size());
            }
        });

        list2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 1) {
                    int selectedIndex = list2.getSelectedIndex();
                    list2.setSelectedIndex(selectedIndex);
                }
            }
        });

        rezerveEtButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (yolcuSayiCheck >= 1) {
                    int sayi = list2.getModel().getSize();
                    int selectedIndex1 = list2.getSelectedIndex();
                    int koltukSec = (int) koltukList.get(selectedIndex1);
                    Transport transport = new Transport(0,0,"","");
                    int seciliKoltuk = transport.koltukSec(koltukSec);
                    koltukList.remove(selectedIndex1);

                    bosKoltuk.setText("Boş koltuk: " + (--sayi));

                    int select = list1.getSelectedIndex();
                    String arac = (String) aracAdList.get(select);
                    String firma = (String) firmaAdList.get(select);

                    String input = JOptionPane.showInputDialog("Ad soyad / Doğum Tarihi / TC no");
                    String inputs[] = input.split("/");

                    if (yolcuSayiCheck > 1) {
                        JOptionPane.showMessageDialog(null, "Bir tane daha koltuk seçiniz");
                        rezerveEtButton.setText("Rezerve Et");
                        yolcuSayiCheck--;
                    } else if (yolcuSayiCheck == 1) {
                        JOptionPane.showMessageDialog(null, "Tüm yolcular için koltuklar başarıyla seçildi");
                        rezerveEtButton.setText("Ödeme Yap");
                        yolcuSayiCheck--;
                    }

                    Passenger yolcu = new Passenger(inputs[0], inputs[1], inputs[2]);
                    Reservation rezervasyon = new Reservation(yolcu, arac, firma, seciliKoltuk);
                    Route rota = new Route(selectedInputs.kalkisNoktasi, selectedInputs.varisNoktasi, selectedInputs.tarih, arac, firma);
                    Customer musteri = new Customer(rezervasyon, rota);

                    Extra.yeniEkle(musteri);
                } else {
                    JOptionPane.showMessageDialog(null, "Ödeme başarılı bir şekilde yapıldı.");
                }
            }
        });

        biletleriGoruntuleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int i = 0; i < Customer.musteriList.size(); i++) {
                    Customer gecici = Customer.musteriList.get(i);
                    JOptionPane.showMessageDialog(null, (i + 1) + ". Yolcu" +
                            "\nAd-Soyad: " + gecici.rezervasyon.yolcu.ad +
                           "\nDoğum Tarihi: " + gecici.rezervasyon.yolcu.dogumTarih +
                            "\nTC no: " + gecici.rezervasyon.yolcu.tcNo +
                            "\nKoltuk no: " + gecici.rezervasyon.koltukBilgisi);
                }
            }
        });
    }
}