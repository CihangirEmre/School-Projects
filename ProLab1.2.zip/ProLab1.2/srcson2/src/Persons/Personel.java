package Persons;

public class Personel extends Person {
    public int kullananUcret;
    public int personelUcret;

    public Personel(int kullananUcret, int personelUcret) {
        super("");
        this.kullananUcret = kullananUcret;
        this.personelUcret = personelUcret;
    }

    static public Personel calisanUcret(String firmaAd, String aracAd) {
        int kullananUcret = 0;
        int personelUcret = 0;

        if (firmaAd.equals("A")) {
            kullananUcret = 5000;
            personelUcret = 2000;
        } else if (firmaAd.equals("B")) {
            kullananUcret = 3000;
            personelUcret = 1500;
        } else if (firmaAd.equals("C")) {
            if (aracAd.contains("otobus")) {
                kullananUcret = 4000;
                personelUcret = 2000;
            } else if (aracAd.contains("ucak")) {
                kullananUcret = 10000;
                personelUcret = 6000;
            }
        } else if (firmaAd.contains("D")) {
            kullananUcret = 2000;
            personelUcret = 1000;
        } else if (firmaAd.contains("F")) {
            kullananUcret = 7500;
            personelUcret = 4000;
        } else {
            if (aracAd.contains("otobus")) {
                kullananUcret = 5000;
                personelUcret = 2500;
            } else if (aracAd.contains("tren")) {
                kullananUcret = 2000;
                personelUcret = 1000;
            } else if (aracAd.contains("ucak")) {
                kullananUcret = 8000;
                personelUcret = 4000;
            }
        }

        return new Personel(kullananUcret, personelUcret);
    }
}
