package Persons;

public class Passenger extends Person {
    public String tcNo;
    public String dogumTarih;

    public Passenger(String ad, String dogumTarih, String tcNo) {
        super(ad);
        this.dogumTarih = dogumTarih;
        this.tcNo = tcNo;

    }
}
