package Persons;

public abstract class Person {
    public String ad;

    public Person(String ad) { this.ad = ad; }
}
