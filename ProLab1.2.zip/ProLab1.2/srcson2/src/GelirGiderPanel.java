import Others.CompanyEarnings;
import Others.Content;
import Others.Transport;
import Users.Company;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class GelirGiderPanel extends JFrame {

    private JList list1;
    private JPanel panel1;

    DefaultListModel listModel1 = new DefaultListModel();
    List<String> tarihList = new ArrayList<>();
    List<Integer> gelirList = new ArrayList<>();
    List<Integer> giderList = new ArrayList<>();

    private String[] tarihler = {"04.12.2023", "05.12.2023", "06.12.2023", "07.12.2023",
            "08.12.2023", "09.12.2023", "10.12.2023"};

    public GelirGiderPanel() {
        add(panel1);
        setTitle("Gelir-Gider");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Content.icerikList.clear();
        CompanyEarnings.hesapla();
        for (Content c : Content.icerikList) {
            for (CompanyEarnings a : c.list) {
                if (a.firmaAd.equals(Company.kullaniciAdi)) {
                    tarihList.add(c.tarih);
                    gelirList.add(a.gelir);
                    giderList.add(a.gider);
                }
            }
        }

        for (String tarih : tarihler) {
            boolean check = false;
            int gel = 0;
            int gid = 0;

            for (int i = 0; i < tarihList.size(); i++) {
                if (tarihList.get(i).equals(tarih)) {
                    gel += gelirList.get(i);
                    gid += giderList.get(i);
                    check = true;
                }
            }

            if (check) {
                Company a = new Company("", "");
                int son = a.karZararDurumu(gel, gid);
                listModel1.addElement("Tarih: " + tarih + "  Gelir: " + gel + "  Gider: " + gid + "  Son durum: " + son);
            }
        }
        list1.setModel(listModel1);
    }
}
